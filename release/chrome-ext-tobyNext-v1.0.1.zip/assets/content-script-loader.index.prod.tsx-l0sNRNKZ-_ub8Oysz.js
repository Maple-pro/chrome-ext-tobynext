(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/index.prod.tsx-l0sNRNKZ.js")
    );
  })().catch(console.error);

})();
